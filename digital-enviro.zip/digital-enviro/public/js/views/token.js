/* Token wallet: balance, earn, send, spend in the perks shop, and the member-to-member market (when the owner opens it). */
(function () {
  const DE = window.DE, esc = DE.esc, $ = DE.$, $$ = DE.$$;
  const fmt = u => (Math.round(u) / 100).toLocaleString(undefined, { maximumFractionDigits: 2 });
  const KIND = { mine: 'Earned', daily: 'Daily reward', bonus: 'Welcome bonus', mint: 'Granted', send: 'Sent', receive: 'Received', fee: 'Fee', perk: 'Bought', ai: 'AI question', income: 'Income', escrow: 'Offer (held)', escrow_return: 'Offer returned', trade_buy: 'Bought on market', burn: 'Removed' };

  DE.route('/token', async view => {
    DE.title('Token wallet');
    let me, br = { enabled: false, networks: [], history: [] }, perks = [], pb = { rate: 0, invoices: [], ads: [] }, mk = { open: false, offers: [], mine: [], last: [] };
    async function load() {
      me = await DE.get('/token/me');
      perks = me.spend ? await DE.get('/token/perks').catch(() => []) : [];
      pb = me.pay_rate > 0 ? await DE.get('/token/payables').catch(() => pb) : pb;
      br = me.enabled ? await DE.get('/token/bridge/info').catch(() => br) : br;
      mk = me.market ? await DE.get('/token/market').catch(() => mk) : mk;
      draw();
    }
    function draw() {
      const sym = esc(me.symbol);
      view.innerHTML = '<h1>🪙 ' + esc(me.name) + '</h1>' +
        (!me.enabled ? '<div class="card warnbox">The token is switched off by the site owner right now.</div>' : '') +
        (me.paused ? '<div class="card warnbox">The token is paused by the site owner. Sending and spending are stopped for now.</div>' : '') +
        (me.frozen ? '<div class="card warnbox">Your balance is frozen by the site owner.' + (me.frozen_note ? ' Reason: ' + esc(me.frozen_note) : '') + '</div>' : '') +
        '<div class="card goldcard"><div class="muted small">Your balance' + (me.tier ? ' · <span class="tier tier-' + me.tier + '">🪙 ' + me.tier + ' holder</span>' : '') + '</div><div class="bal" style="font-size:2rem">' + fmt(me.balance) + ' <span class="muted" style="font-size:1rem">' + sym + '</span></div>' +
        '<div class="muted small">Earned so far: ' + fmt(me.earned) + ' ' + sym + (me.ai_credits ? ' · AI credits: ' + me.ai_credits : '') + '</div>' +
        (me.daily_reward > 0 ? '<button class="btn primary" id="claim" style="margin-top:10px"' + (me.can_claim && !me.blocked ? '' : ' disabled') + '>' + (me.can_claim ? 'Claim daily reward: +' + fmt(me.daily_reward) + ' ' + sym : 'Daily reward claimed ✔') + '</button>' : '') + '</div>' +
        '<div class="card"><h3>Ways to earn</h3>' + (me.earn.length ? me.earn.map(e => '<div class="row between" style="padding:4px 0"><span>' + esc(e.label) + '</span><b>+' + fmt(e.units) + ' ' + sym + '</b></div>').join('') + '<div class="muted small" style="margin-top:6px">Today: ' + fmt(me.earned_today) + (me.daily_cap ? ' of ' + fmt(me.daily_cap) : '') + ' ' + sym + '. Rewards are for real activity and are limited each day.</div>' : '<p class="muted">The owner has not switched on any earning activities yet.</p>') + '</div>' +
        (me.transfers ? '<div class="card"><h3>Send tokens</h3><form id="sf"><div class="two"><div><label class="f">To (username)</label><input class="i" id="to" autocomplete="off" required></div><div><label class="f">Amount</label><input class="i" id="am" type="number" step="0.01" min="0.01" required></div></div><label class="f">Note (optional)</label><input class="i" id="nt" maxlength="120"><div class="muted small">' + (me.fee_percent ? 'A ' + me.fee_percent + '% fee applies. ' : '') + 'Most you can send at once: ' + fmt(me.max_transfer) + ' ' + sym + '.</div><div class="err" id="se"></div><button class="btn primary" style="margin-top:8px"' + (me.blocked ? ' disabled' : '') + '>Send</button></form></div>' : '') +
        (me.spend ? '<div class="card"><h3>Spend tokens</h3>' + (perks.length ? perks.map(p => '<div class="row" style="padding:8px 0;border-bottom:1px solid var(--line)"><div class="grow"><b>' + esc(p.name) + '</b><div class="muted small">' + esc(p.description || '') + '</div></div><button class="btn sm primary" data-buy="' + p.id + '">' + fmt(p.cost) + ' ' + sym + '</button></div>').join('') : '<p class="muted">Nothing in the shop yet.</p>') + (me.ai_cost ? '<p class="muted small">After your free daily AI questions, each extra question costs ' + fmt(me.ai_cost) + ' ' + sym + '.</p>' : '') + '</div>' : '') +
        payHtml(sym) + bridgeHtml(sym) + (mk.open ? marketHtml(sym) : '') +
        '<div class="card"><h3>History</h3>' + (me.ledger.length ? me.ledger.map(l => '<div class="row between" style="padding:5px 0;border-bottom:1px solid var(--line)"><div><b>' + esc(KIND[l.kind] || l.kind) + '</b><div class="muted small">' + esc(l.note || '') + ' · ' + esc(DE.timeago(l.created_at)) + '</div></div><b style="color:var(' + (l.delta >= 0 ? '--ok' : '--danger') + ')">' + (l.delta >= 0 ? '+' : '') + fmt(l.delta) + '</b></div>').join('') : '<p class="muted">No activity yet.</p>') + '</div>' +
        '<p class="muted small center">' + esc(me.name) + ' is a points token that works inside this community. It is not an investment, and nobody can promise it will be worth any amount.</p>';
      bind();
    }
    function payHtml(sym) {
      if (!(pb.rate > 0) || (!pb.invoices.length && !pb.ads.length)) return '';
      return '<div class="card"><h3>Pay with tokens</h3><p class="muted small">Pay platform fees and adverts with ' + sym + '.</p>' +
        pb.invoices.map(i => '<div class="row between" style="padding:5px 0"><span>' + esc(i.note || i.kind) + ' <span class="muted small">(' + DE.money(i.amount, i.currency) + ')</span></span><button class="btn sm primary" data-pinv="' + i.id + '">' + fmt(i.tokens) + ' ' + sym + '</button></div>').join('') +
        pb.ads.map(a => '<div class="row between" style="padding:5px 0"><span>Advert: ' + esc(a.title) + ' <span class="muted small">(' + DE.money(a.amount, a.currency) + ')</span></span><button class="btn sm primary" data-pad="' + a.id + '">' + fmt(a.tokens) + ' ' + sym + '</button></div>').join('') + '</div>';
    }
    const nets = () => br.networks.map(n => '<option value="' + esc(n.id) + '">' + esc(n.name) + (n.testnet ? ' (test)' : '') + '</option>').join('');
    const hex = s => Array.from(new TextEncoder().encode(s)).map(b => b.toString(16).padStart(2, '0')).join('');
    const NATIVE = { 56: 'BNB', 97: 'tBNB', 137: 'POL', 80002: 'POL', 8453: 'ETH', 84532: 'ETH' };
    function bridgeHtml(sym) {
      if (!br.enabled || !br.networks.length) return '';
      const tx = h => { const n = br.networks.find(x => x.id === h.network); return h.tx_hash && n && n.explorer ? ' · <a href="' + esc(n.explorer) + '/tx/' + esc(h.tx_hash) + '" target="_blank" rel="noopener">view</a>' : ''; };
      return '<div class="card"><h3>⛓ On the blockchain</h3><p class="muted small">Move ' + sym + ' to your own crypto wallet on BNB Smart Chain, Polygon or Base, and back. Test networks use coins with no real value.</p>' +
        (br.address ? '<div class="small">Linked wallet: <code>' + esc(br.address) + '</code> <a href="#" id="unlink">remove</a></div>' : '<button class="btn primary" id="linkw">Link my wallet</button><p class="muted small">Needs a wallet app such as MetaMask or Trust Wallet. You sign a message to prove the wallet is yours; this costs nothing.</p>') +
        (br.address ? '<h4>Withdraw to my wallet</h4><form id="bo"><div class="two"><div><label class="f">Network</label><select class="i" id="bon">' + nets() + '</select></div><div><label class="f">Amount</label><input class="i" id="boa" type="number" step="0.01" min="0.01" required></div></div><div class="muted small">Smallest ' + fmt(br.min) + ', largest ' + fmt(br.max) + (br.fee_percent ? ', fee ' + br.fee_percent + '%' : '') + '. ' + (br.auto ? 'Sent automatically.' : 'The owner approves each withdrawal first.') + '</div><div class="err" id="boe"></div><button class="btn" style="margin-top:8px">Withdraw</button></form>' +
        '<h4>Deposit from my wallet</h4><form id="bd"><div class="two"><div><label class="f">Network</label><select class="i" id="bdn">' + nets() + '</select></div><div><label class="f">Amount</label><input class="i" id="bda" type="number" step="0.01" min="0.01" required></div></div><div class="err" id="bde"></div><button class="btn" style="margin-top:8px">Deposit to the app</button><div class="muted small">Your wallet needs a little of the network\'s coin for the fee. Tokens arrive in the app after the network confirms (a few minutes).</div></form>' : '') +
        (br.history.length ? '<h4>Blockchain activity</h4>' + br.history.map(h => '<div class="row between small" style="padding:4px 0"><span>' + (h.direction === 'out' ? 'Withdraw ' : 'Deposit ') + fmt(h.units) + ' ' + sym + tx(h) + '</span><span class="pill ' + (h.status === 'done' ? 'ok' : h.status === 'failed' ? 'bad' : 'warn') + '">' + esc(h.status) + '</span></div>').join('') : '') + '</div>';
    }
    async function wallet() {
      if (!window.ethereum) throw new Error('Open this page inside a wallet app such as MetaMask or Trust Wallet.');
      const acc = await window.ethereum.request({ method: 'eth_requestAccounts' });
      return acc[0];
    }
    function marketHtml(sym) {
      return '<div class="card"><h3>Member market</h3><p class="muted small">Buy tokens from other members with your wallet money, or sell yours. Tokens are held safely while an offer is open. Fee: ' + mk.fee_percent + '%.</p>' +
        (mk.offers.length ? mk.offers.map(o => '<div class="row" style="padding:6px 0;border-bottom:1px solid var(--line)"><div class="grow"><b>' + fmt(o.remaining) + ' ' + sym + '</b> from @' + esc(o.username) + '<div class="muted small">' + DE.money(o.price, o.currency) + ' per token</div></div>' + (o.username === DE.user.username ? '' : '<button class="btn sm primary" data-mbuy="' + o.id + '" data-max="' + o.remaining + '">Buy</button>') + '</div>').join('') : '<p class="muted">No offers right now.</p>') +
        '<h4>Sell my tokens</h4><form id="of"><div class="two"><div><label class="f">How many</label><input class="i" id="oa" type="number" step="0.01" min="0.01" required></div><div><label class="f">Price for 1 token</label><input class="i" id="op" type="number" step="0.01" min="0.01" required></div></div><label class="f">Currency</label>' + DE.currencySelect('oc') + '<div class="err" id="oe"></div><button class="btn" style="margin-top:8px">Create offer</button></form>' +
        (mk.mine.filter(x => x.status === 'open').length ? '<h4>My open offers</h4>' + mk.mine.filter(x => x.status === 'open').map(o => '<div class="row between" style="padding:4px 0"><span>' + fmt(o.remaining) + ' ' + sym + ' at ' + DE.money(o.price, o.currency) + '</span><button class="btn sm danger" data-oc="' + o.id + '">Cancel</button></div>').join('') : '') + '</div>';
    }
    function bind() {
      $$('[data-pinv],[data-pad]').forEach(b => b.onclick = async () => { const inv = !!b.dataset.pinv; if (!await DE.confirm('Pay with tokens?', 'Pay')) return; try { await DE.post('/token/pay/' + (inv ? 'invoice/' + b.dataset.pinv : 'ad/' + b.dataset.pad)); DE.toast('Paid'); load(); } catch (e) { DE.fail(e); } });
      const q = DE.query ? DE.query() : {}; if (q && q.to && $('#to') && !$('#to').value) $('#to').value = q.to;
      const lw = $('#linkw'); if (lw) lw.onclick = async () => { try { const a = await wallet(); const { message } = await DE.get('/token/bridge/nonce'); const sig = await window.ethereum.request({ method: 'personal_sign', params: ['0x' + hex(message), a] }); await DE.post('/token/bridge/link', { address: a, signature: sig }); DE.toast('Wallet linked'); load(); } catch (e) { DE.fail(e); } };
      const ul = $('#unlink'); if (ul) ul.onclick = async e => { e.preventDefault(); if (await DE.confirm('Remove this wallet?', 'Remove')) { await DE.del('/token/bridge/link'); load(); } };
      const bo = $('#bo'); if (bo) bo.onsubmit = async e => { e.preventDefault(); $('#boe').textContent = ''; try { const r = await DE.post('/token/bridge/out', { network: $('#bon').value, amount: $('#boa').value }); DE.toast(r.auto ? 'Sending to your wallet…' : 'Withdrawal requested. Waiting for approval.'); load(); } catch (ex) { $('#boe').textContent = ex.message; } };
      const bd = $('#bd'); if (bd) bd.onsubmit = async e => {
        e.preventDefault(); $('#bde').textContent = '';
        try {
          const a = await wallet(); if (a.toLowerCase() !== String(br.address).toLowerCase()) throw new Error('Select your linked wallet (' + br.address.slice(0, 8) + '…) in your wallet app.');
          const d = await DE.post('/token/bridge/deposit-data', { network: $('#bdn').value, amount: $('#bda').value });
          try { await window.ethereum.request({ method: 'wallet_switchEthereumChain', params: [{ chainId: d.chain_id }] }); }
          catch (se) { if (se && se.code === 4902) await window.ethereum.request({ method: 'wallet_addEthereumChain', params: [{ chainId: d.chain_id, chainName: d.chain_name, rpcUrls: [d.rpc_url], blockExplorerUrls: d.explorer ? [d.explorer] : [], nativeCurrency: { name: NATIVE[parseInt(d.chain_id, 16)] || 'ETH', symbol: NATIVE[parseInt(d.chain_id, 16)] || 'ETH', decimals: 18 } }] }); else throw se; }
          await window.ethereum.request({ method: 'eth_sendTransaction', params: [{ from: a, to: d.to, data: d.data }] });
          DE.toast('Sent. Your tokens will appear after the network confirms.');
        } catch (ex) { $('#bde').textContent = ex.message || 'Cancelled'; }
      };
      const c = $('#claim'); if (c) c.onclick = async () => { try { const r = await DE.post('/token/claim'); DE.toast('+' + fmt(r.amount) + ' ' + me.symbol); load(); } catch (e) { DE.fail(e); } };
      const sf = $('#sf'); if (sf) sf.onsubmit = async e => { e.preventDefault(); $('#se').textContent = ''; try { await DE.post('/token/send', { to_username: $('#to').value, amount: $('#am').value, note: $('#nt').value }); DE.toast('Sent'); load(); } catch (ex) { $('#se').textContent = ex.message; } };
      $$('[data-buy]').forEach(b => b.onclick = async () => { if (!await DE.confirm('Buy this item?', 'Buy')) return; try { const r = await DE.post('/token/perks/' + b.dataset.buy + '/buy'); DE.toast(r.pending ? 'Bought. The owner will deliver it soon.' : 'Done!'); load(); } catch (e) { DE.fail(e); } });
      $$('[data-mbuy]').forEach(b => b.onclick = async () => {
        const max = parseInt(b.dataset.max, 10) / 100;
        DE.modal('<h2>Buy tokens</h2><label class="f">How many? (up to ' + max + ')</label><input class="i" id="ba" type="number" step="0.01" min="0.01" max="' + max + '" value="' + max + '"><div class="err" id="be"></div><div class="row" style="margin-top:12px"><button class="btn primary" id="bg">Buy</button><button class="btn" data-close>Cancel</button></div>', (m, close) => {
          m.querySelector('#bg').onclick = async () => { try { const r = await DE.post('/token/market/offers/' + b.dataset.mbuy + '/buy', { amount: m.querySelector('#ba').value }); close(); DE.toast('Bought ' + fmt(r.units) + ' for ' + DE.money(r.cost, r.currency)); load(); } catch (e) { m.querySelector('#be').textContent = e.message; } };
        });
      });
      const of = $('#of'); if (of) of.onsubmit = async e => { e.preventDefault(); $('#oe').textContent = ''; try { await DE.post('/token/market/offers', { amount: $('#oa').value, price: $('#op').value, currency: $('#oc').value }); DE.toast('Offer created'); load(); } catch (ex) { $('#oe').textContent = ex.message; } };
      $$('[data-oc]').forEach(b => b.onclick = async () => { try { await DE.post('/token/market/offers/' + b.dataset.oc + '/cancel'); DE.toast('Offer cancelled'); load(); } catch (e) { DE.fail(e); } });
    }
    view.innerHTML = '<div class="spinner"></div>';
    try { await load(); } catch (e) { view.innerHTML = '<div class="card empty">' + esc(e.message) + '</div>'; }
  }, { auth: true });
})();

/*
 * Utility token ledger (in-app). 1 token = 100 units (2 decimals). Every change goes through move(), inside a transaction,
 * and leaves a ledger row, so balances can always be audited. The owner controls everything from the dashboard:
 * global on/off and pause, who can send/spend, per-user freeze or restriction, rewards, fees, caps and the maximum supply.
 */
const { db, getSetting, notify } = require('./db');

const UNIT = 100;
const toUnits = v => Math.round(parseFloat(v) * UNIT) || 0;
const fmt = u => (u / UNIT).toFixed(2).replace(/\.00$/, '');
const num = (k, d) => { const n = parseFloat(getSetting(k)); return Number.isFinite(n) ? n : d; };
const on = k => getSetting(k) === '1';
const info = () => ({ name: getSetting('token_name') || 'Enviro Token', symbol: getSetting('token_symbol') || 'ENVO' });
const ownerId = () => { const r = db.prepare("SELECT id FROM users WHERE role='admin' ORDER BY id LIMIT 1").get(); return r ? r.id : null; };
const today = () => new Date().toISOString().slice(0, 10);

function account(userId) {
  db.prepare('INSERT OR IGNORE INTO token_accounts(user_id) VALUES(?)').run(userId);
  return db.prepare('SELECT * FROM token_accounts WHERE user_id=?').get(userId);
}
function fail(msg, status) { return Object.assign(new Error(msg), { status: status || 400 }); }

/** Can this person use the token right now? Returns an error message, or null when they can. */
function blocked(user, what) {
  if (!on('token_enabled')) return 'The token is switched off by the site owner.';
  const isOwner = user && user.role === 'admin';
  if (isOwner) return null;
  if (on('token_paused')) return 'The token is paused by the site owner. Nothing can be sent or spent for now.';
  const restricted = String((user && user.restrictions) || '').split(',').filter(Boolean);
  if (restricted.includes('all') || restricted.includes('token')) return 'The site owner has restricted your account from using the token.' + (user.restriction_note ? ' Reason: ' + user.restriction_note : '');
  const acc = account(user.id);
  if (acc.frozen) return 'Your token balance is frozen by the site owner.' + (acc.frozen_note ? ' Reason: ' + acc.frozen_note : '');
  if (what === 'send' && !on('token_transfers_enabled')) return 'Sending tokens is switched off at the moment.';
  if (what === 'spend' && !on('token_spend_enabled')) return 'Spending tokens is switched off at the moment.';
  if (what === 'reward' && !on('token_rewards_enabled')) return 'Token rewards are switched off at the moment.';
  return null;
}

// Tokens inside the app plus tokens currently out on the blockchain, so the maximum supply covers both.
const outstanding = () => db.prepare("SELECT COALESCE(SUM(CASE WHEN direction='out' AND status IN ('pending','approved','sending','sent') THEN units+fee WHEN direction='out' AND status='done' THEN units WHEN direction='in' AND status='done' THEN -units ELSE 0 END),0) AS s FROM token_bridge").get().s;
const circulating = () => db.prepare('SELECT COALESCE(SUM(balance),0) AS s FROM token_accounts').get().s + Math.max(0, outstanding());

/** The one place balances change. delta > 0 adds, delta < 0 removes (never below zero). */
const move = db.transaction((userId, delta, kind, note, otherId, byId) => {
  const acc = account(userId);
  const next = acc.balance + delta;
  if (next < 0) throw fail('Not enough tokens.');
  db.prepare('UPDATE token_accounts SET balance=? WHERE user_id=?').run(next, userId);
  db.prepare('INSERT INTO token_ledger(user_id,delta,balance_after,kind,note,other_id,by_id) VALUES(?,?,?,?,?,?,?)')
    .run(userId, delta, next, kind, String(note || '').slice(0, 200), otherId || null, byId || null);
  return next;
});

/** Creates new tokens (rewards, owner mint). Respects the maximum supply. */
function mint(userId, units, kind, note, byId) {
  if (units <= 0) throw fail('Enter an amount above zero.');
  const cap = toUnits(getSetting('token_max_supply'));
  if (cap > 0 && circulating() + units > cap) throw fail('This would go over the maximum supply of ' + fmt(cap) + ' ' + info().symbol + '.');
  return move(userId, units, kind, note, null, byId);
}
/** Removes tokens from circulation. */
function burn(userId, units, kind, note, byId) {
  if (units <= 0) throw fail('Enter an amount above zero.');
  return move(userId, -units, kind, note, null, byId);
}

const send = db.transaction((from, toId, units, note) => {
  const min = toUnits(getSetting('token_min_transfer')) || 1, max = toUnits(getSetting('token_max_transfer'));
  if (units < min) throw fail('The smallest amount you can send is ' + fmt(min) + ' ' + info().symbol + '.');
  if (max > 0 && units > max) throw fail('The most you can send at once is ' + fmt(max) + ' ' + info().symbol + '.');
  const dayLimit = toUnits(getSetting('token_daily_send_limit'));
  if (dayLimit > 0 && from.role !== 'admin') {
    const sent = -db.prepare("SELECT COALESCE(SUM(delta),0) AS s FROM token_ledger WHERE user_id=? AND kind='send' AND date(created_at)=date('now')").get(from.id).s;
    if (sent + units > dayLimit) throw fail('Daily sending limit reached (' + fmt(dayLimit) + ' ' + info().symbol + ' a day).');
  }
  const feePct = from.role === 'admin' ? 0 : Math.max(0, Math.min(50, num('token_transfer_fee_percent', 0)));
  const fee = Math.floor(units * feePct / 100);
  move(from.id, -(units + fee), 'send', note, toId);
  move(toId, units, 'receive', note, from.id);
  if (fee > 0) { const o = ownerId(); if (o) move(o, fee, 'fee', 'Transfer fee', from.id); }
  return { fee };
});

/** Spend tokens on something in the app (AI questions, perks). */
function spend(user, units, kind, note) {
  const why = blocked(user, 'spend'); if (why) throw fail(why, 403);
  const burnPct = Math.max(0, Math.min(100, num('token_spend_burn_percent', 0)));
  const burned = Math.floor(units * burnPct / 100);
  move(user.id, -units, kind, note);
  // what is spent goes to the owner's balance (minus the share the owner chose to burn), so supply stays traceable
  const o = ownerId();
  if (o && o !== user.id && units - burned > 0) move(o, units - burned, 'income', note, user.id);
  if (burned > 0 && o) db.prepare("INSERT INTO token_ledger(user_id,delta,balance_after,kind,note,other_id) VALUES(?,?,?,?,?,?)").run(o, 0, account(o).balance, 'burned', 'Burned from spending', burned);
}

function claimDaily(user) {
  const why = blocked(user, 'reward'); if (why) throw fail(why, 403);
  const amt = toUnits(getSetting('token_daily_reward'));
  if (amt <= 0) throw fail('Daily rewards are not switched on.');
  const acc = account(user.id);
  if (acc.last_claim === today()) throw fail('You already claimed today. Come back tomorrow!');
  mint(user.id, amt, 'daily', 'Daily reward');
  db.prepare('UPDATE token_accounts SET last_claim=? WHERE user_id=?').run(today(), user.id);
  return amt;
}

function signupBonus(userId) {
  try {
    if (!on('token_enabled') || !on('token_rewards_enabled')) return;
    const amt = toUnits(getSetting('token_signup_bonus'));
    if (amt > 0) { mint(userId, amt, 'bonus', 'Welcome bonus'); notify(userId, 'token', 'You received ' + fmt(amt) + ' ' + info().symbol + ' as a welcome bonus.', '/token'); }
  } catch (e) { /* never block sign-up */ }
}

const EARN = { post: 'Posting', comment: 'Commenting', like_received: 'A reaction on your post', class_join: 'Joining a class' };

/**
 * Activity mining: small token rewards for real activity in the community. Everything is capped per day and each action
 * can only be rewarded once, so repeating or faking activity earns nothing extra. The owner sets amounts and caps (or 0 to switch one off).
 * Never throws: a reward problem must never break the action it follows.
 */
function earn(userId, activity, ref) {
  try {
    if (!on('token_enabled') || !on('token_rewards_enabled') || on('token_paused')) return 0;
    let amt = toUnits(getSetting('token_earn_' + activity));
    const half = toUnits(getSetting('token_halving_supply'));
    if (half > 0) amt = Math.floor(amt / Math.pow(2, Math.floor(circulating() / half)));  // rewards halve each time another slice of supply is in circulation
    if (amt <= 0) return 0;
    const u = db.prepare('SELECT id,role,restrictions,restriction_note,status,created_at FROM users WHERE id=?').get(userId);
    if (!u || u.status !== 'active' || blocked(u, 'reward')) return 0;
    const minH = num('token_earn_min_account_hours', 0);
    if (minH > 0 && (Date.now() - new Date(String(u.created_at).replace(' ', 'T') + 'Z').getTime()) < minH * 3600e3) return 0;
    const day = today();
    const cap = toUnits(getSetting('token_earn_daily_cap'));
    const got = db.prepare('SELECT COALESCE(SUM(units),0) s, COALESCE(SUM(activity=?),0) n FROM token_earn_log WHERE user_id=? AND day=?').get(activity, userId, day);
    if (cap > 0 && got.s + amt > cap) return 0;
    const maxN = parseInt(getSetting('token_earn_max_per_activity'), 10) || 0;
    if (maxN > 0 && got.n >= maxN) return 0;
    const run = db.transaction(() => {
      const ins = db.prepare('INSERT OR IGNORE INTO token_earn_log(user_id,activity,ref,units,day) VALUES(?,?,?,?,?)').run(userId, activity, String(ref), amt, day);
      if (!ins.changes) return 0;
      mint(userId, amt, 'mine', EARN[activity] || activity);
      return amt;
    });
    return run();
  } catch (e) { return 0; }
}

/** Gold / Silver / Bronze by balance. The owner sets the thresholds. */
function tierOf(units) {
  const g = toUnits(getSetting('token_tier_gold')), s = toUnits(getSetting('token_tier_silver')), b = toUnits(getSetting('token_tier_bronze'));
  if (g > 0 && units >= g) return 'gold';
  if (s > 0 && units >= s) return 'silver';
  if (b > 0 && units >= b) return 'bronze';
  return null;
}
/** How many tokens an amount of money costs, at the owner's rate (tokens per 1 US dollar). 0 means paying with tokens is off. */
function quote(minor, currency) {
  const rate = num('token_pay_rate', 0);
  if (rate <= 0) return 0;
  const fx = require('./fx'), world = require('./world');
  const per = fx.perUsd(currency); if (!per) return 0;
  const usd = (minor / world.factor(currency)) / per;
  return Math.max(1, Math.ceil(usd * rate * UNIT));
}

function status(user) {
  const acc = account(user.id);
  const amt = toUnits(getSetting('token_daily_reward'));
  return {
    ...info(), enabled: on('token_enabled'), paused: on('token_paused'), balance: acc.balance, frozen: !!acc.frozen, frozen_note: acc.frozen_note, ai_credits: acc.ai_credits,
    transfers: on('token_transfers_enabled'), spend: on('token_spend_enabled'), rewards: on('token_rewards_enabled'),
    daily_reward: amt, can_claim: amt > 0 && acc.last_claim !== today(), fee_percent: num('token_transfer_fee_percent', 0),
    min_transfer: toUnits(getSetting('token_min_transfer')), max_transfer: toUnits(getSetting('token_max_transfer')), ai_cost: toUnits(getSetting('token_ai_cost')),
    blocked: blocked(user, 'send'), tier: tierOf(acc.balance), pay_rate: num('token_pay_rate', 0),
    tiers: { bronze: toUnits(getSetting('token_tier_bronze')), silver: toUnits(getSetting('token_tier_silver')), gold: toUnits(getSetting('token_tier_gold')) }
  };
}

module.exports = { UNIT, toUnits, fmt, info, account, blocked, move, mint, burn, send, spend, claimDaily, signupBonus, earn, EARN, tierOf, quote, outstanding, status, circulating, ownerId, on };

const jwt = require('jsonwebtoken');
const { db } = require('./db');
const { jwtSecret } = require('./secrets');
const { clientCountry } = require('./utils');

const seen = new Map(); // userId -> last time we wrote last_seen (keeps the database quiet)

const COOKIE = 'de_session';
const MAX_AGE_MS = 30 * 24 * 3600 * 1000;

/** Signs a login token. Changing the password (or "log out everywhere") bumps token_version and kills old tokens. */
function sign(user) {
  return jwt.sign({ id: user.id, v: user.token_version || 0 }, jwtSecret, { expiresIn: '30d' });
}

function verifyToken(token) {
  try {
    const { id, v } = jwt.verify(token, jwtSecret);
    const u = db.prepare('SELECT id,username,email,phone,display_name,avatar,role,status,is_creator,favoured,restrictions,restriction_note,token_version,country,permissions,owner_fee_waived FROM users WHERE id=?').get(id);
    if (!u || u.status !== 'active' || (u.token_version || 0) !== (v || 0)) return null;
    return u;
  } catch (e) { return null; }
}

function parseCookies(header) {
  const out = {};
  String(header || '').split(';').forEach(p => {
    const i = p.indexOf('=');
    if (i > 0) { try { out[p.slice(0, i).trim()] = decodeURIComponent(p.slice(i + 1).trim()); } catch (e) { /* ignore */ } }
  });
  return out;
}

/** The login token lives in an httpOnly cookie, so page scripts (and any XSS) can never read it. */
function setSession(req, res, user) {
  const secure = req.secure || String(req.headers['x-forwarded-proto'] || '').includes('https');
  res.cookie(COOKIE, sign(user), { httpOnly: true, sameSite: 'lax', secure, maxAge: MAX_AGE_MS, path: '/' });
}
function clearSession(res) { res.clearCookie(COOKIE, { path: '/' }); }

function tokenFrom(req) {
  const c = parseCookies(req.headers.cookie)[COOKIE];
  if (c) return c;
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : null;
}

function optionalAuth(req, res, next) {
  const t = tokenFrom(req);
  req.user = t ? verifyToken(t) : null;
  next();
}

function requireAuth(req, res, next) {
  const t = tokenFrom(req);
  const u = t ? verifyToken(t) : null;
  if (!u) return res.status(401).json({ error: 'Please log in to continue.' });
  req.user = u;
  const now = Date.now();
  if (now - (seen.get(u.id) || 0) > 5 * 60 * 1000) {
    seen.set(u.id, now);
    db.prepare('UPDATE users SET last_seen=CURRENT_TIMESTAMP, last_country=COALESCE(?,last_country) WHERE id=?').run(clientCountry(req), u.id);
  }
  next();
}

function requireAdmin(req, res, next) {
  requireAuth(req, res, () => {
    if (req.user.role !== 'admin') return res.status(403).json({ error: 'Admins only.' });
    next();
  });
}

/**
 * CSRF protection for cookie sessions: every state-changing API call must carry a custom header
 * (browsers refuse to add it on cross-site requests without a CORS preflight, which this site never allows),
 * and if an Origin header is present it must be this site.
 */
function csrfGuard(req, res, next) {
  if (['GET', 'HEAD', 'OPTIONS'].includes(req.method)) return next();
  if (/^\/api\/(pay|pod)\/webhook\//.test(req.originalUrl) || /^\/api\/dropship\/api\//.test(req.originalUrl)) return next(); // server-to-server, signed or secret-in-URL
  if (req.headers['x-requested-with'] !== 'DigitalEnviro') return res.status(403).json({ error: 'Blocked: missing security header.' });
  const origin = req.headers.origin;
  if (origin) {
    try { if (new URL(origin).host !== req.headers.host) return res.status(403).json({ error: 'Blocked: cross-site request.' }); }
    catch (e) { return res.status(403).json({ error: 'Blocked: bad origin.' }); }
  }
  next();
}

// ---------- Admin roles ----------
// role 'admin' = the owner (super admin: can do everything, and is the only one who can create or change other admins).
// role 'staff' = an admin the owner created; they can only do what the owner ticked for them (Admin > Team).
const PERMISSIONS = {
  users_view: 'See the user list, countries and activity',
  users_private: 'See private details: email, phone number, date of birth',
  users_manage: 'Suspend, restrict and favour users, reset passwords',
  users_delete: 'Delete user accounts',
  content: 'Moderate posts, reels, pages, communities, products and classes',
  reports: 'Handle user reports',
  payments_view: 'See transactions, wallets and withdrawals',
  payments_manage: 'Approve manual payments, pay out withdrawals, waive or create fees',
  settings_payments: 'Payment providers, exchange rates, owner receiving accounts',
  fees: 'Set class-hosting and creator fees and payment switches',
  announcements: 'Send announcements and notifications',
  ads: 'Manage advertising',
  writeups: 'Edit write-ups, custom pages and the policy',
  site: 'Theme, menus, categories and feature switches',
  ai: 'Manage AI providers',
  dropship: 'Oversee stores, suppliers and dropship orders',
  db_read: 'Browse database tables (read only)',
  audit: 'View the audit log'
};

function hasPerm(user, key) {
  if (!user) return false;
  if (user.role === 'admin') return true;
  return user.role === 'staff' && String(user.permissions || '').split(',').includes(key);
}
const isStaff = user => !!user && (user.role === 'admin' || (user.role === 'staff' && !!String(user.permissions || '').trim()));

/** Allows the owner, or a staff member who has at least one of the listed permissions. */
function requirePerm(...keys) {
  return (req, res, next) => requireAuth(req, res, () => {
    if (keys.some(k => hasPerm(req.user, k))) return next();
    res.status(403).json({ error: 'The owner has not given you permission for this.' });
  });
}
function requireStaff(req, res, next) {
  requireAuth(req, res, () => (isStaff(req.user) ? next() : res.status(403).json({ error: 'Admins only.' })));
}

function featureOn(key) {
  return (req, res, next) => {
    const f = db.prepare('SELECT enabled FROM feature_flags WHERE key=?').get(key);
    if (f && !f.enabled) return res.status(403).json({ error: 'This feature is currently turned off by the site owner.' });
    next();
  };
}

const RESTRICTION_KEYS = {
  post: 'post content', comment: 'comment', chat: 'send chat messages', follow: 'follow people', sell: 'sell products or run stores',
  withdraw: 'withdraw money', community: 'create communities', page: 'create creator pages', class: 'host classes', ai: 'use the AI assistant', ads: 'run adverts'
};

/** Blocks a feature for users the site owner has restricted (set in Admin > Users). Use after requireAuth. */
function restrict(key) {
  return (req, res, next) => {
    const list = String((req.user && req.user.restrictions) || '').split(',').filter(Boolean);
    if (list.includes('all') || list.includes(key)) {
      return res.status(403).json({ error: 'The site owner has restricted your account from being able to ' + (RESTRICTION_KEYS[key] || key) + '.' + (req.user.restriction_note ? ' Reason: ' + req.user.restriction_note : '') });
    }
    next();
  };
}

module.exports = { PERMISSIONS, hasPerm, isStaff, requirePerm, requireStaff, COOKIE, sign, verifyToken, parseCookies, setSession, clearSession, optionalAuth, requireAuth, requireAdmin, csrfGuard, featureOn, restrict, RESTRICTION_KEYS };

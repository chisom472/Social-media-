// AI tutor / assistant. The owner adds any AI provider in Admin > AI (OpenAI-style, Anthropic or Gemini). Keys are stored encrypted.
// Several providers can be added: they are tried in priority order, so one going down does not stop the assistant.
const { db, getSetting } = require('./db');
const secrets = require('./secrets');
const { safeFetch } = require('./utils');

const TYPES = {
  openai: { label: 'OpenAI-compatible (OpenAI, Groq, OpenRouter, Together, Mistral, DeepSeek...)', base: 'https://api.openai.com/v1' },
  anthropic: { label: 'Anthropic (Claude)', base: 'https://api.anthropic.com' },
  gemini: { label: 'Google Gemini', base: 'https://generativelanguage.googleapis.com' }
};

function activeProviders() {
  return db.prepare('SELECT * FROM ai_providers WHERE enabled=1 ORDER BY priority, id').all().filter(p => p.api_key);
}
const ready = () => activeProviders().length > 0;

function systemPrompt() {
  return [getSetting('ai_system_prompt'), 'About this website (use it to help people use the site):\n' + getSetting('ai_knowledge')].filter(Boolean).join('\n\n');
}

async function callProvider(p, system, messages) {
  const key = secrets.decrypt(p.api_key);
  const base = String(p.base_url || TYPES[p.type].base).replace(/\/+$/, '');
  let r, j;
  if (p.type === 'anthropic') {
    r = await safeFetch(base + '/v1/messages', {
      method: 'POST', headers: { 'content-type': 'application/json', 'x-api-key': key, 'anthropic-version': '2023-06-01' },
      body: JSON.stringify({ model: p.model, max_tokens: 1200, system, messages })
    }, { timeoutMs: 45000 });
    j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error((j.error && j.error.message) || 'Anthropic error ' + r.status);
    return (j.content || []).filter(c => c.type === 'text').map(c => c.text).join('\n');
  }
  if (p.type === 'gemini') {
    r = await safeFetch(base + '/v1beta/models/' + encodeURIComponent(p.model) + ':generateContent', {
      method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': key },
      body: JSON.stringify({ systemInstruction: { parts: [{ text: system }] }, contents: messages.map(m => ({ role: m.role === 'assistant' ? 'model' : 'user', parts: [{ text: m.content }] })), generationConfig: { maxOutputTokens: 1200 } })
    }, { timeoutMs: 45000 });
    j = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error((j.error && j.error.message) || 'Gemini error ' + r.status);
    return ((j.candidates || [])[0] && j.candidates[0].content.parts || []).map(x => x.text).join('');
  }
  r = await safeFetch(base + '/chat/completions', {
    method: 'POST', headers: { 'content-type': 'application/json', authorization: 'Bearer ' + key },
    body: JSON.stringify({ model: p.model, max_tokens: 1200, messages: [{ role: 'system', content: system }, ...messages] })
  }, { timeoutMs: 45000 });
  j = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error((j.error && (j.error.message || j.error)) || 'AI error ' + r.status);
  return j.choices && j.choices[0] && j.choices[0].message ? j.choices[0].message.content : '';
}

/** Returns { reply, provider } or throws if every provider failed. */
async function ask(messages) {
  const list = activeProviders();
  if (!list.length) throw Object.assign(new Error('The AI assistant is coming soon.'), { status: 503, soon: true });
  const system = systemPrompt();
  let last = null;
  for (const p of list) {
    try {
      const reply = await callProvider(p, system, messages);
      if (reply && reply.trim()) return { reply: reply.trim(), provider: p.name };
    } catch (e) { last = e; console.error('[ai:' + p.name + ']', e.message); }
  }
  throw Object.assign(new Error('The assistant is busy right now. Please try again in a moment.'), { status: 502, detail: last && last.message });
}

module.exports = { TYPES, ready, ask };

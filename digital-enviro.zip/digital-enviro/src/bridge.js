/*
 * Bridge between the in-app token ledger and token contracts on EVM chains (BNB Smart Chain, Polygon, Base, or any other you add).
 * Untested against a live chain. Use the test networks first. Needs the "ethers" package (npm install).
 *
 *  App -> chain : member asks to withdraw; tokens leave their balance; the bridge wallet mints on the chain (after your approval, or automatically).
 *  Chain -> app : member calls bridgeToApp() on the contract; tokens are burned there; after enough confirmations they are credited in the app.
 */
const crypto = require('crypto');
const { db, getSetting, notify } = require('./db');
const tokens = require('./token');

const SCALE = 10n ** 16n; // 1 in-app unit (0.01 token) = 1e16 wei (18 decimals)
const ABI = ['function mint(address to, uint256 amount)', 'function bridgeToApp(uint256 amount)', 'event BridgedToApp(address indexed from, uint256 amount)'];
let E = null;
const eth = () => E || (E = require('ethers'));
const on = () => getSetting('bridge_enabled') === '1' && tokens.on('token_enabled');
const num = (k, d) => { const n = parseFloat(getSetting(k)); return Number.isFinite(n) ? n : d; };
const fail = (m, s) => Object.assign(new Error(m), { status: s || 400 });
const lc = a => String(a || '').toLowerCase();

const providers = new Map();
function networks(all) { return db.prepare('SELECT * FROM bridge_networks' + (all ? '' : " WHERE enabled=1 AND contract!=''") + ' ORDER BY testnet DESC, id').all(); }
function network(id) { return db.prepare("SELECT * FROM bridge_networks WHERE id=? AND enabled=1 AND contract!=''").get(String(id || '')); }
function provider(n) {
  const k = n.id + '|' + n.rpc_url;
  if (!providers.has(k)) providers.set(k, new (eth().JsonRpcProvider)(n.rpc_url, Number(n.chain_id), { staticNetwork: true }));
  return providers.get(k);
}
function signer(n) {
  const key = getSetting('bridge_relayer_key');
  if (!key) throw fail('The bridge wallet is not set up yet.', 503);
  return new (eth().Wallet)(key.startsWith('0x') ? key : '0x' + key, provider(n));
}
function relayerAddress() { try { const k = getSetting('bridge_relayer_key'); return k ? new (eth().Wallet)(k.startsWith('0x') ? k : '0x' + k).address : null; } catch (e) { return null; } }

// ---- linking a member's wallet (they prove they own it by signing a message)
const nonces = new Map();
function linkMessage(user) {
  const nonce = crypto.randomBytes(8).toString('hex');
  nonces.set(user.id, { nonce, exp: Date.now() + 10 * 60e3 });
  return 'Link this wallet to my Digital Enviro account @' + user.username + '. Code: ' + nonce;
}
function link(user, address, signature) {
  const n = nonces.get(user.id);
  if (!n || n.exp < Date.now()) throw fail('That link request expired. Try again.');
  let addr;
  try { addr = eth().getAddress(String(address)); } catch (e) { throw fail('That is not a valid wallet address.'); }
  const msg = 'Link this wallet to my Digital Enviro account @' + user.username + '. Code: ' + n.nonce;
  let rec; try { rec = eth().verifyMessage(msg, String(signature)); } catch (e) { throw fail('The signature is not valid.'); }
  if (lc(rec) !== lc(addr)) throw fail('The signature does not match this wallet.');
  const other = db.prepare('SELECT user_id FROM token_linked_wallets WHERE lower(address)=?').get(lc(addr));
  if (other && other.user_id !== user.id) throw fail('This wallet is already linked to another member.');
  db.prepare('INSERT INTO token_linked_wallets(user_id,address) VALUES(?,?) ON CONFLICT(user_id) DO UPDATE SET address=excluded.address, verified_at=CURRENT_TIMESTAMP').run(user.id, addr);
  nonces.delete(user.id);
  claimUnclaimed(user.id, addr);
  return addr;
}
function linked(userId) { const r = db.prepare('SELECT address FROM token_linked_wallets WHERE user_id=?').get(userId); return r ? r.address : null; }

/** Deposits that arrived before the sender linked their wallet are credited as soon as they do. */
function claimUnclaimed(userId, addr) {
  db.prepare("SELECT * FROM token_bridge WHERE direction='in' AND status='unclaimed' AND lower(address)=?").all(lc(addr)).forEach(r => {
    db.transaction(() => {
      db.prepare("UPDATE token_bridge SET status='done', user_id=?, updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='unclaimed'").run(userId, r.id);
      tokens.move(userId, r.units, 'bridge_in', 'From the blockchain', null);
    })();
    notify(userId, 'token', tokens.fmt(r.units) + ' ' + tokens.info().symbol + ' arrived from the blockchain.', '/token');
  });
}

// ---- app -> chain
function requestOut(user, networkId, units) {
  if (!on()) throw fail('The blockchain bridge is switched off.', 403);
  const why = tokens.blocked(user, 'send'); if (why) throw fail(why, 403);
  const n = network(networkId); if (!n) throw fail('Choose a network that is open.');
  const addr = linked(user.id); if (!addr) throw fail('Link your wallet first.');
  const min = tokens.toUnits(getSetting('bridge_min_out')) || 1, max = tokens.toUnits(getSetting('bridge_max_out'));
  if (units < min) throw fail('The smallest withdrawal is ' + tokens.fmt(min) + ' ' + tokens.info().symbol + '.');
  if (max > 0 && units > max) throw fail('The most you can withdraw at once is ' + tokens.fmt(max) + ' ' + tokens.info().symbol + '.');
  const day = tokens.toUnits(getSetting('bridge_daily_out_limit'));
  if (day > 0 && user.role !== 'admin') {
    const used = db.prepare("SELECT COALESCE(SUM(units),0) s FROM token_bridge WHERE user_id=? AND direction='out' AND status NOT IN ('failed','cancelled','rejected') AND date(created_at)=date('now')").get(user.id).s;
    if (used + units > day) throw fail('Daily withdrawal limit reached.');
  }
  const fee = user.role === 'admin' ? 0 : Math.floor(units * Math.max(0, Math.min(30, num('bridge_out_fee_percent', 0))) / 100);
  return db.transaction(() => {
    tokens.move(user.id, -(units + fee), 'bridge_out', 'Withdrawal to ' + n.name, null);
    const auto = getSetting('bridge_auto') === '1';
    return db.prepare('INSERT INTO token_bridge(user_id,direction,units,fee,network,address,status) VALUES(?,?,?,?,?,?,?)').run(user.id, 'out', units, fee, n.id, addr, auto ? 'approved' : 'pending').lastInsertRowid;
  })();
}
function refund(row, why) {
  db.transaction(() => {
    const r = db.prepare("SELECT * FROM token_bridge WHERE id=? AND direction='out' AND status IN ('pending','approved','sending','sent')").get(row.id);
    if (!r) return;
    db.prepare("UPDATE token_bridge SET status=?, error=?, updated_at=CURRENT_TIMESTAMP WHERE id=?").run('failed', String(why || '').slice(0, 300), r.id);
    if (r.user_id && r.kind !== 'faucet') tokens.move(r.user_id, r.units + r.fee, 'bridge_refund', 'Withdrawal returned', null);
  })();
  if (row.user_id && row.kind !== 'faucet') notify(row.user_id, 'token', 'Your withdrawal to the blockchain did not go through. Your tokens were returned.', '/token');
}

let busy = false;
async function processOut() {
  const rows = db.prepare("SELECT * FROM token_bridge WHERE direction='out' AND status='approved' ORDER BY id LIMIT 5").all();
  for (const r of rows) {
    const n = db.prepare('SELECT * FROM bridge_networks WHERE id=?').get(r.network);
    if (!n || !n.enabled) continue;
    db.prepare("UPDATE token_bridge SET status='sending', updated_at=CURRENT_TIMESTAMP WHERE id=? AND status='approved'").run(r.id);
    try {
      const c = new (eth().Contract)(n.contract, ABI, signer(n));
      const tx = await c.mint(r.address, BigInt(r.units) * SCALE);
      db.prepare("UPDATE token_bridge SET status='sent', tx_hash=?, updated_at=CURRENT_TIMESTAMP WHERE id=?").run(tx.hash, r.id);
    } catch (e) {
      // Could not even send: safe to hand the tokens back
      refund(r, e.shortMessage || e.message);
    }
  }
  const sent = db.prepare("SELECT * FROM token_bridge WHERE direction='out' AND status='sent'").all();
  for (const r of sent) {
    const n = db.prepare('SELECT * FROM bridge_networks WHERE id=?').get(r.network); if (!n) continue;
    try {
      const rc = await provider(n).getTransactionReceipt(r.tx_hash);
      if (!rc) continue;
      if (rc.status === 1) {
        db.transaction(() => {
          db.prepare("UPDATE token_bridge SET status='done', updated_at=CURRENT_TIMESTAMP WHERE id=?").run(r.id);
          const o = tokens.ownerId(); if (o && r.fee > 0) tokens.move(o, r.fee, 'income', 'Bridge fee', r.user_id);
        })();
        if (r.user_id) notify(r.user_id, 'token', tokens.fmt(r.units) + ' ' + tokens.info().symbol + ' reached your wallet on ' + n.name + '.', '/token');
      } else refund(r, 'Transaction failed on the chain');
    } catch (e) { /* try again next round */ }
  }
}

// ---- chain -> app
async function watchDeposits() {
  for (const n of networks()) {
    try {
      const key = 'block:' + n.id;
      const st = db.prepare('SELECT value FROM bridge_state WHERE key=?').get(key);
      const p = provider(n);
      const latest = await p.getBlockNumber();
      const safe = latest - (n.confirmations || 12);
      if (!st) { db.prepare('INSERT INTO bridge_state(key,value) VALUES(?,?)').run(key, String(safe)); continue; } // start from now: older events are not replayed
      let from = parseInt(st.value, 10) + 1;
      if (from > safe) continue;
      const c = new (eth().Contract)(n.contract, ABI, p);
      while (from <= safe) {
        const to = Math.min(safe, from + 1999);
        const logs = await c.queryFilter(c.filters.BridgedToApp(), from, to);
        for (const lg of logs) {
          const units = Number(lg.args.amount / SCALE);
          const logKey = n.id + ':' + lg.transactionHash + ':' + lg.index;
          const addr = lg.args.from;
          const owner = db.prepare('SELECT user_id FROM token_linked_wallets WHERE lower(address)=?').get(lc(addr));
          db.transaction(() => {
            const ins = db.prepare("INSERT OR IGNORE INTO token_bridge(user_id,direction,units,network,address,tx_hash,log_key,status) VALUES(?,?,?,?,?,?,?,?)")
              .run(owner ? owner.user_id : null, 'in', units, n.id, addr, lg.transactionHash, logKey, owner ? 'done' : 'unclaimed');
            if (ins.changes && owner) tokens.move(owner.user_id, units, 'bridge_in', 'From ' + n.name, null);
          })();
          if (owner) notify(owner.user_id, 'token', tokens.fmt(units) + ' ' + tokens.info().symbol + ' arrived from ' + n.name + '.', '/token');
        }
        db.prepare('INSERT INTO bridge_state(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key, String(to));
        from = to + 1;
      }
      db.prepare('DELETE FROM bridge_state WHERE key=?').run('err:' + n.id);
    } catch (e) { db.prepare('INSERT INTO bridge_state(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run('err:' + n.id, String(e.shortMessage || e.message).slice(0, 200)); }
  }
}

async function tick() {
  if (busy || getSetting('bridge_enabled') !== '1') return;
  busy = true;
  try { await processOut(); await watchDeposits(); } finally { busy = false; }
}

function depositData(networkId, units) {
  const n = network(networkId); if (!n) throw fail('Choose a network that is open.');
  if (units <= 0) throw fail('Enter an amount above zero.');
  const data = new (eth().Interface)(ABI).encodeFunctionData('bridgeToApp', [BigInt(units) * SCALE]);
  return { chain_id: '0x' + Number(n.chain_id).toString(16), chain_name: n.name, rpc_url: n.rpc_url, explorer: n.explorer, to: n.contract, data };
}

module.exports = { on, networks, network, linkMessage, link, linked, requestOut, refund, tick, depositData, relayerAddress, processOut };

// =====================================================================================
// Faucets. "Test" faucets hand out test-network tokens (no value). "Real" faucets hand out the real on-chain token and only to
// members who earned enough by activity. Both are off until the owner switches them on, and both are limited per person, wallet,
// network address and day. Claims use the same approval queue and bridge wallet as withdrawals.
// =====================================================================================
const fnum = (k, d) => { const n = parseFloat(getSetting(k)); return Number.isFinite(n) ? n : d; };
function faucetCheck(user, n, ip) {
  const kind = n.testnet ? 'test' : 'real';
  if (!on()) return 'The blockchain bridge is switched off.';
  if (getSetting('faucet_' + kind + '_enabled') !== '1') return 'This faucet is not open.';
  const why = tokens.blocked(user, 'reward'); if (why) return why;
  if (!linked(user.id)) return 'Link your wallet first.';
  const u = db.prepare('SELECT created_at,country FROM users WHERE id=?').get(user.id);
  const ageDays = (Date.now() - new Date(String(u.created_at).replace(' ', 'T') + 'Z').getTime()) / 864e5;
  if (ageDays < fnum('faucet_min_account_days', 0)) return 'Your account must be at least ' + fnum('faucet_min_account_days', 0) + ' days old.';
  const blockedC = String(getSetting('faucet_blocked_countries') || '').toUpperCase().split(/[,\s]+/).filter(Boolean);
  if (u.country && blockedC.includes(String(u.country).toUpperCase())) return 'This faucet is not available in your country.';
  if (kind === 'real') {
    const earned = db.prepare("SELECT COALESCE(SUM(delta),0) s FROM token_ledger WHERE user_id=? AND kind IN ('mine','daily','bonus')").get(user.id).s;
    const need = tokens.toUnits(getSetting('faucet_real_min_earned'));
    if (earned < need) return 'Earn at least ' + tokens.fmt(need) + ' ' + tokens.info().symbol + ' through activity first (you have earned ' + tokens.fmt(earned) + ').';
  }
  const amount = tokens.toUnits(getSetting('faucet_' + kind + '_amount'));
  if (amount <= 0) return 'This faucet has no amount set.';
  const since = d => "datetime('now','-" + Math.max(0, Math.floor(d)) + " days')";
  const cool = fnum('faucet_' + kind + '_cooldown_days', 1);
  const live = "status NOT IN ('failed','rejected','cancelled')";
  const nets = "network IN (SELECT id FROM bridge_networks WHERE testnet=" + (n.testnet ? 1 : 0) + ")";
  if (db.prepare("SELECT 1 FROM token_bridge WHERE kind='faucet' AND user_id=? AND " + nets + " AND " + live + " AND created_at > " + since(cool)).get(user.id)) return 'You already claimed recently. Try again after ' + cool + ' day(s).';
  const addr = linked(user.id);
  if (db.prepare("SELECT 1 FROM token_bridge WHERE kind='faucet' AND lower(address)=? AND " + nets + " AND " + live + " AND created_at > " + since(cool)).get(lc(addr))) return 'This wallet already claimed recently.';
  const ipLim = fnum('faucet_ip_daily_limit', 0);
  if (ipLim > 0 && ip && db.prepare("SELECT COUNT(*) c FROM token_bridge WHERE kind='faucet' AND ip=? AND " + live + " AND created_at > datetime('now','-1 day')").get(ip).c >= ipLim) return 'Too many claims from this network today.';
  const life = tokens.toUnits(getSetting('faucet_' + kind + '_lifetime_cap'));
  const got = db.prepare("SELECT COALESCE(SUM(units),0) s FROM token_bridge WHERE kind='faucet' AND user_id=? AND " + nets + " AND " + live).get(user.id).s;
  if (life > 0 && got + amount > life) return 'You have reached the limit for this faucet.';
  const budget = tokens.toUnits(getSetting('faucet_' + kind + '_daily_budget'));
  const used = db.prepare("SELECT COALESCE(SUM(units),0) s FROM token_bridge WHERE kind='faucet' AND " + nets + " AND " + live + " AND date(created_at)=date('now')").get().s;
  if (budget > 0 && used + amount > budget) return 'The faucet has run out for today. Try again tomorrow.';
  if (kind === 'real') {
    const cap = tokens.toUnits(getSetting('token_max_supply'));
    if (cap > 0 && tokens.circulating() + amount > cap) return 'The maximum supply has been reached.';
  }
  return null;
}
function faucetInfo(user) {
  return networks().map(n => ({ id: n.id, name: n.name, testnet: !!n.testnet, open: getSetting('faucet_' + (n.testnet ? 'test' : 'real') + '_enabled') === '1', amount: tokens.toUnits(getSetting('faucet_' + (n.testnet ? 'test' : 'real') + '_amount')), approval: !n.testnet && getSetting('faucet_real_approval') === '1', problem: faucetCheck(user, n, null) }));
}
function faucetClaim(user, networkId, ip) {
  const n = network(networkId); if (!n) throw fail('Choose a network that is open.');
  const problem = faucetCheck(user, n, ip); if (problem) throw fail(problem);
  const kind = n.testnet ? 'test' : 'real';
  const amount = tokens.toUnits(getSetting('faucet_' + kind + '_amount'));
  const manual = !n.testnet && getSetting('faucet_real_approval') === '1';
  return db.prepare("INSERT INTO token_bridge(user_id,direction,units,fee,network,address,status,kind,ip) VALUES(?,?,?,?,?,?,?,?,?)")
    .run(user.id, 'out', amount, 0, n.id, linked(user.id), manual ? 'pending' : 'approved', 'faucet', ip || null).lastInsertRowid;
}
module.exports.faucetInfo = faucetInfo;
module.exports.faucetClaim = faucetClaim;

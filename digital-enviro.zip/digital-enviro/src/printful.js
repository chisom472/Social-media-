// Printful integration (https://developers.printful.com) - the global print-on-demand / dropshipping platform.
// What it gives us: a product catalogue, worldwide shipping rates, automatic production + delivery straight to the
// customer, the seller's own logo printed on the product (and optionally on the inside label), and a packing slip
// carrying the seller's brand. The owner connects ONE Printful account (Admin > Dropshipping); Printful bills that
// account for the production + shipping cost ("capital") when an order is confirmed.
const { getSetting } = require('./db');
const world = require('./world');

const BASE = 'https://api.printful.com';

const enabled = () => getSetting('printful_enabled') === '1' && !!getSetting('printful_api_token');

async function api(method, endpoint, body, query) {
  const token = getSetting('printful_api_token');
  if (!token) throw Object.assign(new Error('Automatic dropshipping is not connected yet. The site owner must add the Printful token in Admin.'), { status: 503 });
  const headers = { Authorization: 'Bearer ' + token, 'Content-Type': 'application/json' };
  if (getSetting('printful_store_id')) headers['X-PF-Store-Id'] = getSetting('printful_store_id');
  const qs = query ? '?' + new URLSearchParams(query).toString() : '';
  const ctl = new AbortController();
  const t = setTimeout(() => ctl.abort(), 30000);
  let res;
  try { res = await fetch(BASE + endpoint + qs, { method, headers, body: body ? JSON.stringify(body) : undefined, signal: ctl.signal }); }
  catch (e) { throw Object.assign(new Error('Could not reach Printful: ' + e.message), { status: 502, retry: true }); }
  finally { clearTimeout(t); }
  const j = await res.json().catch(() => ({}));
  if (!res.ok || (j.code && j.code >= 400)) {
    const msg = (j.error && (j.error.message || j.error.reason)) || (typeof j.result === 'string' ? j.result : '') || 'Printful error ' + res.status;
    throw Object.assign(new Error(msg), { status: res.status === 429 ? 429 : res.status >= 500 ? 502 : 400, retry: res.status === 429 || res.status >= 500, pf: j });
  }
  return j.result;
}

const minor = (v, cur) => world.toMinor(parseFloat(v) || 0, cur || 'USD');

// ---- catalogue ----
const categories = () => api('GET', '/categories').then(r => r.categories || []);
const products = category => api('GET', '/products', null, category ? { category_id: category } : undefined);
const product = id => api('GET', '/products/' + parseInt(id, 10));

let pfCache = new Map();
/** Print areas for a product: which placements exist and how big each print file is. */
async function printfiles(productId) {
  const hit = pfCache.get(productId);
  if (hit && Date.now() - hit.at < 6 * 3600 * 1000) return hit.data;
  const data = await api('GET', '/mockup-generator/printfiles/' + parseInt(productId, 10));
  pfCache.set(productId, { at: Date.now(), data });
  return data;
}

/** Print file size for one variant + placement (e.g. the "front" of a size-M t-shirt). */
async function printfileFor(productId, variantId, placement) {
  const pf = await printfiles(productId);
  const vp = (pf.variant_printfiles || []).find(v => v.variant_id === variantId);
  const id = vp && vp.placements ? vp.placements[placement] : null;
  const file = (pf.printfiles || []).find(f => f.printfile_id === id);
  return file ? { width: file.width, height: file.height } : null;
}

/** Centres the design in the print area at the chosen size (percent of the print area width). */
function position(area, aspect, scalePct) {
  const aw = area.width, ah = area.height;
  let w = Math.round(aw * Math.min(100, Math.max(10, scalePct || 60)) / 100), h = Math.round(w / (aspect || 1));
  if (h > ah) { h = ah; w = Math.round(h * (aspect || 1)); }
  return { area_width: aw, area_height: ah, width: w, height: h, top: Math.round((ah - h) / 2), left: Math.round((aw - w) / 2), limit_to_print_area: true };
}

// ---- mockups (a picture of the branded product, made by Printful) ----
const mockupTask = (productId, body) => api('POST', '/mockup-generator/create-task/' + parseInt(productId, 10), body);
const mockupResult = key => api('GET', '/mockup-generator/task', null, { task_key: key });

// ---- shipping + orders ----
const shippingRates = body => api('POST', '/shipping/rates', body);
const createOrder = (body, confirm) => api('POST', '/orders', body, confirm ? { confirm: '1' } : undefined);
const confirmOrder = id => api('POST', '/orders/' + encodeURIComponent(id) + '/confirm');
const getOrder = id => api('GET', '/orders/' + encodeURIComponent(id));
const cancelOrder = id => api('DELETE', '/orders/' + encodeURIComponent(id));

// ---- webhooks + account ----
const WEBHOOK_TYPES = ['package_shipped', 'package_returned', 'order_failed', 'order_canceled', 'order_put_hold', 'order_remove_hold', 'order_refunded'];
const setupWebhooks = url => api('POST', '/webhooks', { url, types: WEBHOOK_TYPES });
const webhookConfig = () => api('GET', '/webhooks');
const storeInfo = () => api('GET', '/store');

/** Total cost Printful bills us for an order ("capital"), in minor units, from the costs block of an order. */
function capitalOf(order) {
  const c = order && order.costs;
  if (!c) return null;
  const cur = String(c.currency || 'USD').toUpperCase();
  const total = c.total != null ? c.total : (parseFloat(c.subtotal) || 0) + (parseFloat(c.shipping) || 0) + (parseFloat(c.tax) || 0) + (parseFloat(c.vat) || 0) + (parseFloat(c.digitization) || 0) + (parseFloat(c.additional_fee) || 0) + (parseFloat(c.fulfillment_fee) || 0);
  return { minor: minor(total, cur), currency: cur };
}

/** Width/height of a PNG or JPEG (no libraries needed). */
function imageSize(buf) {
  if (buf.length > 24 && buf.readUInt32BE(0) === 0x89504e47) return { type: 'png', width: buf.readUInt32BE(16), height: buf.readUInt32BE(20) };
  if (buf[0] === 0xff && buf[1] === 0xd8) {
    let i = 2;
    while (i < buf.length - 9) {
      if (buf[i] !== 0xff) { i++; continue; }
      const m = buf[i + 1];
      if (m >= 0xc0 && m <= 0xcf && ![0xc4, 0xc8, 0xcc].includes(m)) return { type: 'jpeg', height: buf.readUInt16BE(i + 5), width: buf.readUInt16BE(i + 7) };
      i += 2 + buf.readUInt16BE(i + 2);
    }
  }
  return null;
}

module.exports = { enabled, api, categories, products, product, printfiles, printfileFor, position, mockupTask, mockupResult, shippingRates, createOrder, confirmOrder, getOrder, cancelOrder, setupWebhooks, webhookConfig, storeInfo, capitalOf, imageSize, minor, WEBHOOK_TYPES };

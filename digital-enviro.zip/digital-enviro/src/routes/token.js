const express = require('express');
const rateLimit = require('express-rate-limit');
const { db, getSetting, notify } = require('../db');
const { requireAuth, requirePerm, hasPerm } = require('../auth');
const tokens = require('../token');
const pay = require('./payments');
const world = require('../world');

const router = express.Router();
const wrap = fn => (req, res) => {
  const onErr = e => { if (!res.headersSent) res.status(e.status || 500).json({ error: e.status ? e.message : 'Something went wrong.' }); };
  try { const r = fn(req, res); if (r && typeof r.catch === 'function') r.catch(onErr); } catch (e) { onErr(e); }
};
const lim = rateLimit({ windowMs: 60 * 1000, max: 30, standardHeaders: true, legacyHeaders: false, message: { error: 'Too many requests. Please slow down.' } });
const unitsOf = v => { const n = tokens.toUnits(v); if (n <= 0) throw Object.assign(new Error('Enter an amount above zero.'), { status: 400 }); return n; };
const userByName = n => db.prepare("SELECT id,username,role,status,restrictions,restriction_note FROM users WHERE username=?").get(String(n || '').toLowerCase().replace(/^@/, ''));
const audit = (req, action, detail) => db.prepare('INSERT INTO audit_log(admin_id,action,detail) VALUES(?,?,?)').run(req.user.id, action, String(detail || '').slice(0, 500));

// Public info (name, symbol, switches) so the menu and pages know whether the token is on
router.get('/info', (req, res) => res.json({ ...tokens.info(), enabled: tokens.on('token_enabled'), market: tokens.on('token_market_enabled') }));

// =====================================================================================
// Members
// =====================================================================================
router.get('/me', requireAuth, wrap((req, res) => {
  const s = tokens.status(req.user);
  const ledger = db.prepare('SELECT id,delta,balance_after,kind,note,created_at FROM token_ledger WHERE user_id=? ORDER BY id DESC LIMIT 50').all(req.user.id);
  const earned = db.prepare("SELECT COALESCE(SUM(delta),0) s FROM token_ledger WHERE user_id=? AND kind IN ('mine','daily','bonus','mint')").get(req.user.id).s;
  const earn = Object.keys(tokens.EARN).map(k => ({ key: k, label: tokens.EARN[k], units: tokens.toUnits(getSetting('token_earn_' + k)) })).filter(e => e.units > 0);
  const today = db.prepare("SELECT COALESCE(SUM(units),0) s FROM token_earn_log WHERE user_id=? AND day=date('now')").get(req.user.id).s;
  res.json({ ...s, ledger, earned, earn, earned_today: today, daily_cap: tokens.toUnits(getSetting('token_earn_daily_cap')), market: tokens.on('token_market_enabled') });
}));

router.post('/send', requireAuth, lim, wrap((req, res) => {
  const why = tokens.blocked(req.user, 'send'); if (why) return res.status(403).json({ error: why });
  const to = userByName((req.body || {}).to_username);
  if (!to || to.status !== 'active') return res.status(404).json({ error: 'Member not found.' });
  if (to.id === req.user.id) return res.status(400).json({ error: "You can't send tokens to yourself." });
  const toWhy = tokens.blocked({ id: to.id, role: to.role, restrictions: to.restrictions, restriction_note: to.restriction_note }, 'receive');
  if (toWhy && to.role !== 'admin') return res.status(400).json({ error: 'That member cannot receive tokens right now.' });
  const units = unitsOf((req.body || {}).amount);
  const r = tokens.send(req.user, to.id, units, String((req.body || {}).note || '').slice(0, 120));
  notify(to.id, 'token', '@' + req.user.username + ' sent you ' + tokens.fmt(units) + ' ' + tokens.info().symbol, '/token');
  res.json({ ok: true, fee: r.fee });
}));

router.post('/claim', requireAuth, lim, wrap((req, res) => { const amt = tokens.claimDaily(req.user); res.json({ ok: true, amount: amt }); }));

// ---- pay the owner with tokens (platform fees and adverts), at the owner's rate. Off while the rate is 0.
router.get('/payables', requireAuth, wrap((req, res) => {
  const rate = parseFloat(getSetting('token_pay_rate')) || 0;
  if (rate <= 0 || !tokens.on('token_enabled')) return res.json({ rate: 0, invoices: [], ads: [] });
  const invoices = db.prepare("SELECT id,kind,note,amount,currency FROM owner_invoices WHERE user_id=? AND status='due'").all(req.user.id).map(i => ({ ...i, tokens: tokens.quote(i.amount, i.currency) }));
  const ads = db.prepare("SELECT id,title,price AS amount,currency FROM ads WHERE owner_id=? AND status='pending_payment'").all(req.user.id).map(a => ({ ...a, tokens: tokens.quote(a.amount, a.currency) }));
  res.json({ rate, invoices, ads });
}));
router.post('/pay/invoice/:id', requireAuth, lim, wrap((req, res) => {
  if (!(parseFloat(getSetting('token_pay_rate')) > 0)) return res.status(403).json({ error: 'Paying with tokens is not switched on.' });
  const inv = db.prepare("SELECT * FROM owner_invoices WHERE id=? AND user_id=? AND status='due'").get(req.params.id, req.user.id);
  if (!inv) return res.status(404).json({ error: 'Invoice not found or already paid.' });
  const cost = tokens.quote(inv.amount, inv.currency); if (!cost) return res.status(400).json({ error: 'No rate is available for this currency.' });
  db.transaction(() => { tokens.spend(req.user, cost, 'invoice', inv.note || 'Platform fee'); require('../ownerfees').markPaid(inv.id, 'tok-' + inv.id); })();
  res.json({ ok: true, tokens: cost });
}));
router.post('/pay/ad/:id', requireAuth, lim, wrap((req, res) => {
  if (!(parseFloat(getSetting('token_pay_rate')) > 0)) return res.status(403).json({ error: 'Paying with tokens is not switched on.' });
  const ad = db.prepare("SELECT * FROM ads WHERE id=? AND owner_id=? AND status='pending_payment'").get(req.params.id, req.user.id);
  if (!ad) return res.status(404).json({ error: 'Advert not found or already paid.' });
  const cost = tokens.quote(ad.price, ad.currency); if (!cost) return res.status(400).json({ error: 'No rate is available for this currency.' });
  db.transaction(() => { tokens.spend(req.user, cost, 'ad', 'Advert: ' + ad.title); require('./ads').onPaid({ ref: 'tok-ad-' + ad.id, target_id: ad.id, buyer_id: req.user.id }); })();
  res.json({ ok: true, tokens: cost });
}));

// ---- perks shop (spend tokens on community services)
router.get('/perks', requireAuth, wrap((req, res) => {
  res.json(db.prepare('SELECT id,name,description,cost,kind,value,stock,per_user_limit FROM token_perks WHERE active=1 AND (stock IS NULL OR stock>0) ORDER BY cost').all());
}));
router.post('/perks/:id/buy', requireAuth, lim, wrap((req, res) => {
  const p = db.prepare('SELECT * FROM token_perks WHERE id=? AND active=1').get(req.params.id);
  if (!p || (p.stock !== null && p.stock <= 0)) return res.status(404).json({ error: 'This item is not available.' });
  if (p.per_user_limit > 0 && db.prepare('SELECT COUNT(*) c FROM token_purchases WHERE user_id=? AND perk_id=?').get(req.user.id, p.id).c >= p.per_user_limit) return res.status(400).json({ error: 'You already have the most you can get of this item.' });
  db.transaction(() => {
    tokens.spend(req.user, p.cost, 'perk', p.name);
    if (p.stock !== null) db.prepare('UPDATE token_perks SET stock=stock-1 WHERE id=?').run(p.id);
    if (p.kind === 'ai_credits') db.prepare('UPDATE token_accounts SET ai_credits=ai_credits+? WHERE user_id=?').run(p.value, req.user.id);
    db.prepare('INSERT INTO token_purchases(user_id,perk_id,perk_name,cost,status) VALUES(?,?,?,?,?)').run(req.user.id, p.id, p.name, p.cost, p.kind === 'custom' ? 'pending' : 'done');
  })();
  const o = tokens.ownerId(); if (o && p.kind === 'custom') notify(o, 'token', '@' + req.user.username + ' bought "' + p.name + '" - it needs your action.', '/admin#token');
  res.json({ ok: true, pending: p.kind === 'custom' });
}));
router.get('/purchases', requireAuth, wrap((req, res) => res.json(db.prepare('SELECT id,perk_name,cost,status,created_at FROM token_purchases WHERE user_id=? ORDER BY id DESC LIMIT 50').all(req.user.id))));

// ---- member-to-member market (owner must switch it on; tokens are held in escrow while an offer is open)
const marketOn = (req, res) => {
  if (!tokens.on('token_market_enabled')) { res.status(403).json({ error: 'The token market is not open. The site owner has not switched it on.' }); return false; }
  const why = tokens.blocked(req.user, 'send'); if (why) { res.status(403).json({ error: why }); return false; }
  return true;
};
router.get('/market', requireAuth, wrap((req, res) => {
  if (!tokens.on('token_market_enabled')) return res.json({ open: false, offers: [] });
  const offers = db.prepare("SELECT o.id,o.remaining,o.units,o.price,o.currency,o.created_at,u.username FROM token_offers o JOIN users u ON u.id=o.seller_id WHERE o.status='open' AND o.remaining>0 ORDER BY o.currency, o.price ASC, o.id ASC LIMIT 100").all();
  const last = db.prepare('SELECT units,cost,currency,created_at FROM token_trades ORDER BY id DESC LIMIT 20').all();
  res.json({ open: true, fee_percent: parseFloat(getSetting('token_market_fee_percent')) || 0, offers, mine: db.prepare("SELECT id,remaining,units,price,currency,status,created_at FROM token_offers WHERE seller_id=? ORDER BY id DESC LIMIT 30").all(req.user.id), last });
}));
router.post('/market/offers', requireAuth, lim, wrap((req, res) => {
  if (!marketOn(req, res)) return;
  const b = req.body || {}; const currency = world.normCurrency(b.currency, null);
  if (!currency) return res.status(400).json({ error: 'Choose a currency.' });
  const units = unitsOf(b.amount); const price = world.toMinor(b.price, currency);
  const minP = world.toMinor(getSetting('token_market_min_price'), currency);
  if (price < 1 || price < minP) return res.status(400).json({ error: 'Set a price for one token.' });
  const id = db.transaction(() => { tokens.move(req.user.id, -units, 'escrow', 'Offer to sell'); return db.prepare('INSERT INTO token_offers(seller_id,units,remaining,price,currency) VALUES(?,?,?,?,?)').run(req.user.id, units, units, price, currency).lastInsertRowid; })();
  res.json({ ok: true, id });
}));
router.post('/market/offers/:id/cancel', requireAuth, wrap((req, res) => {
  const o = db.prepare("SELECT * FROM token_offers WHERE id=? AND status='open'").get(req.params.id);
  if (!o || (o.seller_id !== req.user.id && !hasPerm(req.user, 'token'))) return res.status(404).json({ error: 'Offer not found.' });
  db.transaction(() => { if (o.remaining > 0) tokens.move(o.seller_id, o.remaining, 'escrow_return', 'Offer cancelled'); db.prepare("UPDATE token_offers SET status='cancelled', remaining=0 WHERE id=?").run(o.id); })();
  res.json({ ok: true });
}));
router.post('/market/offers/:id/buy', requireAuth, lim, wrap((req, res) => {
  if (!marketOn(req, res)) return;
  const o = db.prepare("SELECT * FROM token_offers WHERE id=? AND status='open' AND remaining>0").get(req.params.id);
  if (!o) return res.status(404).json({ error: 'This offer is no longer available.' });
  if (o.seller_id === req.user.id) return res.status(400).json({ error: "You can't buy your own offer." });
  const seller = db.prepare('SELECT id,role,restrictions,restriction_note,status FROM users WHERE id=?').get(o.seller_id);
  if (!seller || seller.status !== 'active') return res.status(400).json({ error: 'The seller is not available.' });
  const units = Math.min(unitsOf((req.body || {}).amount), o.remaining);
  const cost = Math.max(1, Math.round(units * o.price / tokens.UNIT));
  const feePct = Math.max(0, Math.min(30, parseFloat(getSetting('token_market_fee_percent')) || 0));
  const fee = Math.floor(cost * feePct / 100);
  db.transaction(() => {
    pay.debit(req.user.id, cost, o.currency, 'token_buy', 'tok' + o.id, 'Bought tokens');
    pay.credit(o.seller_id, cost - fee, o.currency, 'token_sale', 'tok' + o.id, 'Sold tokens');
    const a = pay.adminId(); if (fee > 0 && a) pay.credit(a, fee, o.currency, 'commission', 'tok' + o.id, 'Token market fee');
    tokens.move(req.user.id, units, 'trade_buy', 'Bought from @' + (db.prepare('SELECT username FROM users WHERE id=?').get(o.seller_id) || {}).username, o.seller_id);
    const left = o.remaining - units;
    db.prepare("UPDATE token_offers SET remaining=?, status=? WHERE id=?").run(left, left > 0 ? 'open' : 'filled', o.id);
    db.prepare('INSERT INTO token_trades(offer_id,seller_id,buyer_id,units,cost,fee,currency) VALUES(?,?,?,?,?,?,?)').run(o.id, o.seller_id, req.user.id, units, cost, fee, o.currency);
  })();
  notify(o.seller_id, 'token', '@' + req.user.username + ' bought ' + tokens.fmt(units) + ' ' + tokens.info().symbol + ' from you.', '/token');
  res.json({ ok: true, units, cost, currency: o.currency });
}));

// =====================================================================================
// Owner and permitted admins
// =====================================================================================
const staff = requirePerm('token');
router.get('/admin/overview', staff, wrap((req, res) => {
  const supply = tokens.circulating();
  const s = db.prepare("SELECT COUNT(*) holders FROM token_accounts WHERE balance>0").get().holders;
  const frozen = db.prepare('SELECT COUNT(*) c FROM token_accounts WHERE frozen=1').get().c;
  const top = db.prepare('SELECT a.user_id,u.username,a.balance,a.frozen FROM token_accounts a JOIN users u ON u.id=a.user_id WHERE a.balance>0 ORDER BY a.balance DESC LIMIT 15').all();
  const minted = db.prepare("SELECT COALESCE(SUM(delta),0) s FROM token_ledger WHERE kind IN ('mine','daily','bonus','mint')").get().s;
  const burned = -db.prepare("SELECT COALESCE(SUM(delta),0) s FROM token_ledger WHERE kind='burn'").get().s + db.prepare("SELECT COALESCE(SUM(other_id),0) s FROM token_ledger WHERE kind='burned'").get().s;
  const t = db.prepare("SELECT COUNT(*) n, COALESCE(SUM(units),0) u FROM token_trades").get();
  res.json({ ...tokens.info(), supply, holders: s, frozen, top, minted, burned, trades: t.n, traded_units: t.u, max_supply: tokens.toUnits(getSetting('token_max_supply')), staff_mint_limit: tokens.toUnits(getSetting('token_admin_mint_limit')), owner: req.user.role === 'admin' });
}));
router.get('/admin/ledger', staff, wrap((req, res) => {
  const u = req.query.username ? userByName(req.query.username) : null;
  const rows = u ? db.prepare('SELECT l.*, ? AS username FROM token_ledger l WHERE user_id=? ORDER BY id DESC LIMIT 200').all(u.username, u.id)
    : db.prepare('SELECT l.*, u.username FROM token_ledger l JOIN users u ON u.id=l.user_id ORDER BY l.id DESC LIMIT 200').all();
  res.json(rows);
}));
router.post('/admin/mint', staff, wrap((req, res) => {
  const b = req.body || {}; const u = userByName(b.username); if (!u) return res.status(404).json({ error: 'Member not found.' });
  const units = unitsOf(b.amount);
  if (req.user.role !== 'admin') { const lim2 = tokens.toUnits(getSetting('token_admin_mint_limit')); if (lim2 <= 0 || units > lim2) return res.status(403).json({ error: 'You may only create up to ' + tokens.fmt(lim2) + ' ' + tokens.info().symbol + ' at once. Ask the owner.' }); }
  tokens.mint(u.id, units, 'mint', b.note || 'Granted by admin', req.user.id);
  audit(req, 'token-mint', '@' + u.username + ' +' + tokens.fmt(units) + ' ' + (b.note || ''));
  notify(u.id, 'token', 'You received ' + tokens.fmt(units) + ' ' + tokens.info().symbol + (b.note ? ': ' + String(b.note).slice(0, 80) : ''), '/token');
  res.json({ ok: true });
}));
router.post('/admin/burn', staff, wrap((req, res) => {
  const b = req.body || {}; const u = userByName(b.username); if (!u) return res.status(404).json({ error: 'Member not found.' });
  if (u.role !== 'user' && req.user.role !== 'admin') return res.status(403).json({ error: 'Only the owner can change admin balances.' });
  const units = unitsOf(b.amount);
  tokens.burn(u.id, units, 'burn', b.note || 'Removed by admin', req.user.id);
  audit(req, 'token-burn', '@' + u.username + ' -' + tokens.fmt(units) + ' ' + (b.note || ''));
  res.json({ ok: true });
}));
router.post('/admin/freeze', staff, wrap((req, res) => {
  const b = req.body || {}; const u = userByName(b.username); if (!u) return res.status(404).json({ error: 'Member not found.' });
  if (u.role === 'admin') return res.status(400).json({ error: 'The owner account cannot be frozen.' });
  if (u.role !== 'user' && req.user.role !== 'admin') return res.status(403).json({ error: 'Only the owner can change admin accounts.' });
  tokens.account(u.id);
  db.prepare('UPDATE token_accounts SET frozen=?, frozen_note=? WHERE user_id=?').run(b.frozen ? 1 : 0, b.frozen ? String(b.note || '').slice(0, 200) : null, u.id);
  audit(req, b.frozen ? 'token-freeze' : 'token-unfreeze', '@' + u.username);
  res.json({ ok: true });
}));
router.post('/admin/airdrop', requirePerm('token'), wrap((req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Only the owner can give tokens to everyone.' });
  const units = unitsOf((req.body || {}).amount); const note = String((req.body || {}).note || 'Airdrop').slice(0, 100);
  const users = db.prepare("SELECT id FROM users WHERE status='active' AND role='user'").all();
  const cap = tokens.toUnits(getSetting('token_max_supply'));
  if (cap > 0 && tokens.circulating() + units * users.length > cap) return res.status(400).json({ error: 'This would go over the maximum supply.' });
  db.transaction(() => users.forEach(u => tokens.mint(u.id, units, 'mint', note, req.user.id)))();
  audit(req, 'token-airdrop', users.length + ' members x ' + tokens.fmt(units));
  res.json({ ok: true, members: users.length });
}));
// perks
router.get('/admin/perks', staff, wrap((req, res) => res.json(db.prepare('SELECT * FROM token_perks ORDER BY id DESC').all())));
router.post('/admin/perks', staff, wrap((req, res) => {
  const b = req.body || {}; if (!b.name) return res.status(400).json({ error: 'Give the item a name.' });
  const kind = b.kind === 'ai_credits' ? 'ai_credits' : 'custom';
  db.prepare('INSERT INTO token_perks(name,description,cost,kind,value,stock,per_user_limit,active) VALUES(?,?,?,?,?,?,?,?)')
    .run(String(b.name).slice(0, 80), String(b.description || '').slice(0, 300), unitsOf(b.cost), kind, parseInt(b.value, 10) || 0, b.stock === '' || b.stock == null ? null : parseInt(b.stock, 10), parseInt(b.per_user_limit, 10) || 0, b.active === false ? 0 : 1);
  res.json({ ok: true });
}));
router.put('/admin/perks/:id', staff, wrap((req, res) => {
  const b = req.body || {};
  db.prepare('UPDATE token_perks SET name=COALESCE(?,name), description=COALESCE(?,description), cost=COALESCE(?,cost), value=COALESCE(?,value), stock=?, per_user_limit=COALESCE(?,per_user_limit), active=COALESCE(?,active) WHERE id=?')
    .run(b.name ? String(b.name).slice(0, 80) : null, b.description != null ? String(b.description).slice(0, 300) : null, b.cost != null && b.cost !== '' ? tokens.toUnits(b.cost) : null, b.value != null ? parseInt(b.value, 10) || 0 : null, b.stock === '' || b.stock == null ? null : parseInt(b.stock, 10), b.per_user_limit != null ? parseInt(b.per_user_limit, 10) || 0 : null, b.active != null ? (b.active ? 1 : 0) : null, req.params.id);
  res.json({ ok: true });
}));
router.delete('/admin/perks/:id', staff, wrap((req, res) => { db.prepare('DELETE FROM token_perks WHERE id=?').run(req.params.id); res.json({ ok: true }); }));
router.get('/admin/purchases', staff, wrap((req, res) => res.json(db.prepare('SELECT p.id,p.perk_name,p.cost,p.status,p.created_at,u.username FROM token_purchases p JOIN users u ON u.id=p.user_id ORDER BY p.id DESC LIMIT 100').all())));
router.post('/admin/purchases/:id/fulfil', staff, wrap((req, res) => {
  const p = db.prepare("SELECT * FROM token_purchases WHERE id=? AND status='pending'").get(req.params.id); if (!p) return res.status(404).json({ error: 'Not found.' });
  db.prepare("UPDATE token_purchases SET status='done' WHERE id=?").run(p.id);
  notify(p.user_id, 'token', 'Your "' + p.perk_name + '" is ready.', '/token'); res.json({ ok: true });
}));
router.get('/admin/offers', staff, wrap((req, res) => res.json(db.prepare("SELECT o.id,o.remaining,o.price,o.currency,o.status,u.username FROM token_offers o JOIN users u ON u.id=o.seller_id ORDER BY o.id DESC LIMIT 100").all())));

// =====================================================================================
// Blockchain bridge (members)
// =====================================================================================
const bridge = require('../bridge');
router.get('/bridge/info', requireAuth, wrap((req, res) => {
  const on = bridge.on();
  res.json({
    enabled: on, auto: getSetting('bridge_auto') === '1',
    networks: on ? bridge.networks().map(n => ({ id: n.id, name: n.name, chain_id: n.chain_id, explorer: n.explorer, contract: n.contract, testnet: !!n.testnet })) : [],
    address: bridge.linked(req.user.id), fee_percent: parseFloat(getSetting('bridge_out_fee_percent')) || 0,
    min: tokens.toUnits(getSetting('bridge_min_out')), max: tokens.toUnits(getSetting('bridge_max_out')),
    history: db.prepare('SELECT id,direction,units,fee,network,address,tx_hash,status,error,created_at FROM token_bridge WHERE user_id=? ORDER BY id DESC LIMIT 30').all(req.user.id)
  });
}));
router.get('/bridge/nonce', requireAuth, wrap((req, res) => res.json({ message: bridge.linkMessage(req.user) })));
router.post('/bridge/link', requireAuth, lim, wrap((req, res) => res.json({ ok: true, address: bridge.link(req.user, (req.body || {}).address, (req.body || {}).signature) })));
router.delete('/bridge/link', requireAuth, wrap((req, res) => { db.prepare('DELETE FROM token_linked_wallets WHERE user_id=?').run(req.user.id); res.json({ ok: true }); }));
router.post('/bridge/out', requireAuth, lim, wrap((req, res) => {
  const id = bridge.requestOut(req.user, (req.body || {}).network, unitsOf((req.body || {}).amount));
  res.json({ ok: true, id, auto: getSetting('bridge_auto') === '1' });
}));
router.post('/bridge/deposit-data', requireAuth, wrap((req, res) => {
  if (!bridge.on()) return res.status(403).json({ error: 'The blockchain bridge is switched off.' });
  if (!bridge.linked(req.user.id)) return res.status(400).json({ error: 'Link your wallet first.' });
  res.json(bridge.depositData((req.body || {}).network, unitsOf((req.body || {}).amount)));
}));

// ---- Bridge (owner and permitted admins)
router.get('/admin/bridge', staff, wrap((req, res) => {
  const st = {}; db.prepare("SELECT key,value FROM bridge_state WHERE key LIKE 'err:%'").all().forEach(r => (st[r.key.slice(4)] = r.value));
  res.json({
    owner: req.user.role === 'admin', relayer: req.user.role === 'admin' ? bridge.relayerAddress() : null, outstanding: tokens.outstanding(), errors: st,
    networks: req.user.role === 'admin' ? bridge.networks(true) : bridge.networks(true).map(n => ({ id: n.id, name: n.name, enabled: n.enabled })),
    queue: db.prepare("SELECT b.*, u.username FROM token_bridge b LEFT JOIN users u ON u.id=b.user_id ORDER BY b.id DESC LIMIT 100").all()
  });
}));
router.put('/admin/bridge/networks/:id', requirePerm('token'), wrap((req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Only the owner can change networks.' });
  const b = req.body || {};
  if (b.contract && !/^0x[0-9a-fA-F]{40}$/.test(String(b.contract))) return res.status(400).json({ error: 'That is not a valid contract address.' });
  if (b.rpc_url && !/^https:\/\//.test(String(b.rpc_url))) return res.status(400).json({ error: 'The RPC address must start with https://' });
  db.prepare('UPDATE bridge_networks SET contract=COALESCE(?,contract), rpc_url=COALESCE(?,rpc_url), confirmations=COALESCE(?,confirmations), enabled=COALESCE(?,enabled) WHERE id=?')
    .run(b.contract != null ? String(b.contract).trim() : null, b.rpc_url ? String(b.rpc_url).trim() : null, b.confirmations ? parseInt(b.confirmations, 10) : null, b.enabled != null ? (b.enabled ? 1 : 0) : null, req.params.id);
  audit(req, 'bridge-network', req.params.id + ' ' + JSON.stringify({ enabled: b.enabled, contract: b.contract }));
  res.json({ ok: true });
}));
router.post('/admin/bridge/:id/approve', staff, wrap((req, res) => {
  const r = db.prepare("UPDATE token_bridge SET status='approved', updated_at=CURRENT_TIMESTAMP WHERE id=? AND direction='out' AND status='pending'").run(req.params.id);
  if (!r.changes) return res.status(404).json({ error: 'Not waiting for approval.' });
  audit(req, 'bridge-approve', '#' + req.params.id); res.json({ ok: true });
}));
router.post('/admin/bridge/:id/reject', staff, wrap((req, res) => {
  const row = db.prepare("SELECT * FROM token_bridge WHERE id=? AND direction='out' AND status IN ('pending','approved')").get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found.' });
  bridge.refund(row, (req.body || {}).reason || 'Rejected by the owner'); audit(req, 'bridge-reject', '#' + req.params.id); res.json({ ok: true });
}));
router.post('/admin/bridge/:id/refund-stuck', requirePerm('token'), wrap((req, res) => {
  if (req.user.role !== 'admin') return res.status(403).json({ error: 'Only the owner can do this. Check the chain first: if the tokens were minted, do not refund.' });
  const row = db.prepare("SELECT * FROM token_bridge WHERE id=? AND direction='out' AND status IN ('sending','sent')").get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Not found.' });
  bridge.refund(row, 'Returned by the owner'); audit(req, 'bridge-refund-stuck', '#' + req.params.id); res.json({ ok: true });
}));
router.post('/admin/bridge/run', staff, wrap(async (req, res) => { await bridge.tick(); res.json({ ok: true }); }));

module.exports = router;

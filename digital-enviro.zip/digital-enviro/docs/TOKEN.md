# Enviro Token (in-app utility token)

## What it is
A points-style token that lives inside Digital Enviro. Balances are kept in the app's own database ledger (not on a blockchain), so the owner has full control and every change is recorded.

## Members can
- **Earn** (activity mining): posting, commenting, receiving reactions, joining classes, a daily reward and a welcome bonus. All amounts and daily caps are set by the owner; each action pays once.
- **Store** tokens in their Token wallet (menu, then Token).
- **Send** tokens to other members (limits, fee and daily cap are owner-controlled).
- **Spend** tokens in the shop: extra AI questions, or items the owner delivers. Optional pay-per-question after the free AI limit.
- **Trade** with other members on the member market: sell offers with escrow, bought with wallet money (naira, dollars etc.). The owner must switch the market on and earns a fee on each trade.

## Owner and admin controls (/admin, Utility token)
- Turn the token off, or **pause everything** instantly.
- Give, remove (burn), freeze or unfreeze any member; give tokens to everyone (owner only).
- Set maximum supply, earning amounts, fees and limits.
- Give an admin the "token" permission and a per-action creation limit (0 = cannot create tokens).
- Restrict one member from the token: Users, then the member, then tick "Use the token".
- Full ledger and audit log.

## Blockchain bridge (BNB Smart Chain, Polygon, Base)
- Contract and deploy project: `onchain/` (see onchain/README.md). Untested and unaudited. Use the test networks first.
- Members link their wallet by signing a message, then **withdraw** tokens to it or **deposit** tokens from it on the Token page.
- You control it in /admin, Utility token, Blockchain bridge: master switch, automatic or approve-each-withdrawal, fee, limits, which networks are open, the bridge wallet.
- The chain's supply and the app's balances are kept in step: tokens on a chain are counted against your maximum supply.

## Listing on Binance or other exchanges
This is **not possible from the web app** and not guaranteed by any code. It needs, in order:
1. An on-chain version of the token (see contracts/EnviroToken.sol, unaudited sample) and a smart-contract audit.
2. A way to move balances between the app and the chain (deposits/withdrawals). Not built yet.
3. Legal advice and any licences for the countries involved. In Nigeria, digital assets can count as securities and platforms may need to register with the SEC. Check before selling to the public.
4. The exchange's own application, due diligence, listing fees and real liquidity. Binance and others decide for themselves and most tokens are declined. Smaller decentralised exchanges (for example PancakeSwap) need no approval but need liquidity you provide and carry the same legal duties.

## Earning money honestly
Income comes from the market and transfer fees, shop sales, platform fees and ads, not from the token price rising. Never promise buyers profit or a price. Do not sell tokens as an investment.

## Faucets (both OFF by default)

- **Test faucet**: gives test-network tokens (no value) so members can try linking a wallet, withdrawing and depositing. Use it first to measure demand.
- **Real faucet**: gives real on-chain tokens, but only to members who have *earned* at least `faucet_real_min_earned` through activity. Only the owner can turn it on. By default every claim needs the owner's approval (`faucet_real_approval`).
- Abuse controls: wallet must be linked by signature, minimum account age, cooldown per user and per wallet, daily limit per IP, lifetime cap per user, daily budget, blocked countries, max supply, frozen/restricted users blocked.
- Faucet claims create no debit in the app; they are queued like withdrawals and processed by the bridge job.
- Keep to your country's law (e.g. Nigeria SEC rules on digital assets). Do not promise price or returns. Audit the contract and use a multisig owner before any real-money launch.

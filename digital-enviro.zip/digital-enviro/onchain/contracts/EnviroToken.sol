// SPDX-License-Identifier: MIT
pragma solidity ^0.8.24;

/*
 * Enviro Token (ENVO) - the on-chain side of the Digital Enviro bridge.
 *
 * NOT AUDITED. Test it on a test network first. Get an independent smart-contract audit and legal advice before any
 * public launch, and use a multisig wallet (for example Safe) as the owner, not a single personal wallet.
 *
 * How it works with the app:
 *  - App -> chain: the app's bridge wallet (the "minter") mints tokens to the member's linked address.
 *  - Chain -> app: the member calls bridgeToApp(amount). The tokens are burned and an event is emitted; the app reads
 *    the event and credits the member's in-app balance. Nothing else can burn or mint, so supply stays in step.
 * Controls: hard supply cap, pause everything, block an address, replace the minter.
 * Amounts are multiples of 0.01 token (the app's precision).
 */
import "@openzeppelin/contracts/token/ERC20/ERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Capped.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/ERC20Pausable.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract EnviroToken is ERC20, ERC20Capped, ERC20Pausable, Ownable {
    uint256 public constant UNIT = 1e16; // 0.01 token, the smallest amount the app tracks

    address public minter;
    mapping(address => bool) public blocked;

    event BridgedToApp(address indexed from, uint256 amount);
    event MinterChanged(address indexed minter);
    event BlockedChanged(address indexed account, bool isBlocked);

    constructor(address owner_, uint256 capWholeTokens)
        ERC20("Enviro Token", "ENVO")
        ERC20Capped(capWholeTokens * 1e18)
        Ownable(owner_)
    {}

    function setMinter(address newMinter) external onlyOwner {
        minter = newMinter;
        emit MinterChanged(newMinter);
    }

    /// Called only by the app's bridge wallet when a member withdraws from the app.
    function mint(address to, uint256 amount) external {
        require(msg.sender == minter, "Only the bridge can mint");
        require(amount > 0 && amount % UNIT == 0, "Bad amount");
        _mint(to, amount);
    }

    /// Send tokens back into the app. They are burned here and credited in the app to the member who linked this address.
    function bridgeToApp(uint256 amount) external whenNotPaused {
        require(amount > 0 && amount % UNIT == 0, "Bad amount");
        _burn(msg.sender, amount);
        emit BridgedToApp(msg.sender, amount);
    }

    function pause() external onlyOwner { _pause(); }
    function unpause() external onlyOwner { _unpause(); }

    function setBlocked(address account, bool isBlocked) external onlyOwner {
        blocked[account] = isBlocked;
        emit BlockedChanged(account, isBlocked);
    }

    function _update(address from, address to, uint256 value) internal override(ERC20, ERC20Capped, ERC20Pausable) {
        require(!blocked[from] && !blocked[to], "Address is blocked");
        super._update(from, to, value);
    }
}

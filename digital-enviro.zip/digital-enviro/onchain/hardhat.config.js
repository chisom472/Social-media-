require('dotenv').config();
require('@nomicfoundation/hardhat-toolbox');

const key = process.env.DEPLOYER_PRIVATE_KEY; // a NEW wallet used only for deploying; never your main wallet
const accounts = key ? [key] : [];

module.exports = {
  solidity: { version: '0.8.24', settings: { optimizer: { enabled: true, runs: 200 } } },
  networks: {
    bscTestnet: { url: process.env.BSC_TESTNET_RPC || 'https://data-seed-prebsc-1-s1.bnbchain.org:8545', chainId: 97, accounts },
    bsc: { url: process.env.BSC_RPC || 'https://bsc-dataseed.bnbchain.org', chainId: 56, accounts },
    polygonAmoy: { url: process.env.POLYGON_AMOY_RPC || 'https://rpc-amoy.polygon.technology', chainId: 80002, accounts },
    polygon: { url: process.env.POLYGON_RPC || 'https://polygon-rpc.com', chainId: 137, accounts },
    baseSepolia: { url: process.env.BASE_SEPOLIA_RPC || 'https://sepolia.base.org', chainId: 84532, accounts },
    base: { url: process.env.BASE_RPC || 'https://mainnet.base.org', chainId: 8453, accounts }
  }
};

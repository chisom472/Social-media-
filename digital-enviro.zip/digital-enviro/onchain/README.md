# On-chain token (test network first)

Untested and unaudited. Do these steps on a **test network** with free test coins before anything real.

1. Install Node 20+, then in this folder: `npm install`.
2. Make **two new wallets** (MetaMask, "Create account"): one to deploy, one for the app's bridge. Never use your main wallet.
3. Get free test BNB for both from the BNB Smart Chain testnet faucet.
4. Create `.env` in this folder:
   ```
   DEPLOYER_PRIVATE_KEY=<deployer wallet private key>
   BRIDGE_MINTER=<bridge wallet PUBLIC address>
   TOKEN_CAP_WHOLE=1000000
   ```
5. `npm run compile`, then deploy to each network you want, using the same two wallets:
   - BNB Smart Chain test: `npm run deploy:testnet`
   - Polygon test (Amoy): `npm run deploy:polygon-amoy`
   - Base test (Sepolia): `npm run deploy:base-sepolia`
   - Real networks later: `deploy:mainnet` (BNB), `deploy:polygon`, `deploy:base`.
   Each deployment prints its own contract address. Test coins come from each network's faucet (search "<network> faucet").
6. In the app: /admin, Utility token, Blockchain bridge. Paste the bridge wallet's private key once, then for each network paste its contract address and switch it on. Then switch the bridge on.
7. Members link their wallet on the Token page and can then withdraw to the chain or deposit back.

Before real money: independent smart-contract audit, a multisig owner (Safe), a funded bridge wallet kept small, legal advice, and slow rollout with low limits.

## Faucets
Test networks first. Enable the test faucet in Admin > Token > Bridge. Only enable the real faucet after audit, on a mainnet contract, with approval on.

// Deploys EnviroToken. Usage: npm run deploy:testnet
const hre = require('hardhat');

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  const owner = process.env.TOKEN_OWNER || deployer.address;      // later use a multisig (Safe) address here
  const cap = process.env.TOKEN_CAP_WHOLE || '1000000';             // maximum number of whole tokens that can ever exist
  const minter = process.env.BRIDGE_MINTER;                         // the app's bridge wallet address (public address only)

  console.log('Deploying from', deployer.address, 'owner', owner, 'cap', cap);
  const Token = await hre.ethers.getContractFactory('EnviroToken');
  const token = await Token.deploy(owner, cap);
  await token.waitForDeployment();
  const addr = await token.getAddress();
  console.log('EnviroToken deployed at', addr);

  if (minter && owner.toLowerCase() === deployer.address.toLowerCase()) {
    const tx = await token.setMinter(minter);
    await tx.wait();
    console.log('Minter set to', minter);
  } else {
    console.log('Remember to call setMinter(<bridge wallet address>) from the owner wallet.');
  }
  console.log('Put this address in /admin > Utility token > On-chain bridge > Contract.');
}
main().catch(e => { console.error(e); process.exit(1); });
